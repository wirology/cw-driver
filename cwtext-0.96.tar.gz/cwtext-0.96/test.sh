echo "slow" | ./cwpcm -ss > /dev/audio
echo "medium" | ./cwpcm -sm > /dev/audio
echo "fast" | ./cwpcm -sf > /dev/audio
echo "extra" | ./cwpcm -sf > /dev/audio
echo "default" | ./cwpcm -sf > /dev/audio
